"""
Space Debris Detection & Classification Pipeline
------------------------------------------------
This script implements data preprocessing, feature extraction, 
and deep learning / machine learning classifiers for space debris datasets.
"""

import os
import ast
import json
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.metrics import classification_report, accuracy_score, f1_score

import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader

# Set seed for reproducibility
torch.manual_seed(42)
np.random.seed(42)

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print(f"Using device: {device}")


# ==========================================
# PART 1: ORBITAL DEBRIS CLASSIFICATION (TLE)
# ==========================================

def load_and_preprocess_tle_data():
    """
    Loads orbital dataset files, assigns debris type labels,
    extracts orbital features, and preprocesses data.
    """
    print("\n[1/3] Preprocessing Orbital TLE Datasets...")
    
    files_and_labels = {
        'cosmos.csv': 'Cosmos_Debris',
        'fengyun.csv': 'Fengyun_Debris',
        'iridium.csv': 'Iridium_Debris',
        'rocket_body.csv': 'Rocket_Body'
    }
    
    dataframes = []
    for file, label in files_and_labels.items():
        if os.path.exists(file):
            df = pd.read_csv(file)
            df['Debris_Class'] = label
            dataframes.append(df)
            
    if not dataframes:
        print("Orbital CSV files not found. Skipping Part 1.")
        return None, None, None, None, None
        
    df_combined = pd.concat(dataframes, ignore_index=True)
    
    # Feature Engineering from Orbital Parameters
    # Semi-major axis calculation (approximate from Mean Motion n)
    # mu = 398600.4418 km^3/s^2, n converted to rad/s
    mu = 398600.4418
    n_rad_sec = df_combined['MEAN_MOTION'] * (2 * np.pi / 86400)
    df_combined['SEMI_MAJOR_AXIS'] = (mu / (n_rad_sec ** 2)) ** (1/3)
    
    # Perigee & Apogee height estimation
    R_earth = 6371.0  # Earth radius in km
    df_combined['PERIGEE_ALT'] = df_combined['SEMI_MAJOR_AXIS'] * (1 - df_combined['ECCENTRICITY']) - R_earth
    df_combined['APOGEE_ALT'] = df_combined['SEMI_MAJOR_AXIS'] * (1 + df_combined['ECCENTRICITY']) - R_earth
    
    # Orbital Energy Proxy
    df_combined['SPECIFIC_ORBITAL_ENERGY'] = -mu / (2 * df_combined['SEMI_MAJOR_AXIS'])
    
    feature_cols = [
        'MEAN_MOTION', 'ECCENTRICITY', 'INCLINATION', 'RA_OF_ASC_NODE',
        'ARG_OF_PERICENTER', 'MEAN_ANOMALY', 'BSTAR', 'MEAN_MOTION_DOT',
        'SEMI_MAJOR_AXIS', 'PERIGEE_ALT', 'APOGEE_ALT', 'SPECIFIC_ORBITAL_ENERGY'
    ]
    
    # Clean missing values
    X = df_combined[feature_cols].fillna(df_combined[feature_cols].median())
    
    # Label encoding target
    le = LabelEncoder()
    y = le.fit_transform(df_combined['Debris_Class'])
    
    # Train-Test Split & Normalization
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)
    
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)
    
    return X_train_scaled, X_test_scaled, y_train, y_test, le


class TLEDebrisClassifierNN(nn.Module):
    """
    Deep Neural Network for Orbital Debris Classification.
    """
    def __init__(self, input_dim, num_classes):
        super(TLEDebrisClassifierNN, self).__init__()
        self.net = nn.Sequential(
            nn.Linear(input_dim, 128),
            nn.BatchNorm1d(128),
            nn.ReLU(),
            nn.Dropout(0.3),
            nn.Linear(128, 64),
            nn.BatchNorm1d(64),
            nn.ReLU(),
            nn.Dropout(0.2),
            nn.Linear(64, num_classes)
        )

    def forward(self, x):
        return self.net(x)


def train_orbital_classifiers(X_train, X_test, y_train, y_test, label_encoder):
    """
    Trains Deep Learning Neural Network & Machine Learning Classifiers.
    """
    print("\n[2/3] Training Models on Orbital Debris Dataset...")
    
    # --- 1. PyTorch Deep Neural Network ---
    X_tr_t = torch.tensor(X_train, dtype=torch.float32)
    y_tr_t = torch.tensor(y_train, dtype=torch.long)
    X_te_t = torch.tensor(X_test, dtype=torch.float32)
    y_te_t = torch.tensor(y_test, dtype=torch.long)
    
    train_dataset = torch.utils.data.TensorDataset(X_tr_t, y_tr_t)
    train_loader = DataLoader(train_dataset, batch_size=32, shuffle=True)
    
    num_classes = len(label_encoder.classes_)
    nn_model = TLEDebrisClassifierNN(X_train.shape[1], num_classes).to(device)
    criterion = nn.CrossEntropyLoss()
    optimizer = optim.Adam(nn_model.parameters(), lr=0.001)
    
    nn_model.train()
    for epoch in range(30):
        for bx, by in train_loader:
            bx, by = bx.to(device), by.to(device)
            optimizer.zero_grad()
            out = nn_model(bx)
            loss = criterion(out, by)
            loss.backward()
            optimizer.step()
            
    nn_model.eval()
    with torch.no_grad():
        preds_nn = torch.argmax(nn_model(X_te_t.to(device)), dim=1).cpu().numpy()
        
    print("\n--- Deep Learning (PyTorch MLP) Performance ---")
    print(f"Accuracy: {accuracy_score(y_test, preds_nn):.4f}")
    print(classification_report(y_test, preds_nn, target_names=label_encoder.classes_))
    
    # --- 2. Random Forest Classifier ---
    rf = RandomForestClassifier(n_estimators=100, random_state=42)
    rf.fit(X_train, y_train)
    preds_rf = rf.predict(X_test)
    
    print("\n--- Random Forest Classifier Performance ---")
    print(f"Accuracy: {accuracy_score(y_test, preds_rf):.4f}")


# ==========================================
# PART 2: IMAGE DEBRIS BBOX DETECTION PREDICTOR
# ==========================================

class BoundingBoxDataset(Dataset):
    """
    Dataset module for loading object detection bounding box features.
    """
    def __init__(self, csv_file, max_boxes=10):
        self.df = pd.read_csv(csv_file)
        self.max_boxes = max_boxes

    def __len__(self):
        return len(self.df)

    def __getitem__(self, idx):
        row = self.df.iloc[idx]
        image_id = row['ImageID']
        bboxes = ast.literal_eval(row['bboxes']) if isinstance(row['bboxes'], str) else row['bboxes']
        
        # Standardize bbox padding
        padded_boxes = np.zeros((self.max_boxes, 4), dtype=np.float32)
        count = min(len(bboxes), self.max_boxes)
        if count > 0:
            padded_boxes[:count] = np.array(bboxes[:count], dtype=np.float32)
            
        return torch.tensor(image_id, dtype=torch.long), torch.tensor(padded_boxes, dtype=torch.float32), count


def train_image_debris_model():
    """
    Demonstrates bounding box pipeline execution for image datasets.
    """
    print("\n[3/3] Processing Detection Datasets (train.csv / val.csv / sample_submission.csv)...")
    
    if os.path.exists('train.csv') and os.path.exists('val.csv'):
        train_ds = BoundingBoxDataset('train.csv')
        val_ds = BoundingBoxDataset('val.csv')
        
        train_loader = DataLoader(train_ds, batch_size=64, shuffle=True)
        val_loader = DataLoader(val_ds, batch_size=64, shuffle=False)
        
        for img_id, boxes, counts in train_loader:
            print(f"Batch loaded successfully! Sample batch image IDs shape: {img_id.shape}, BBoxes shape: {boxes.shape}")
            break
            
    print("\nPipeline execution complete!")


# ==========================================
# MAIN EXECUTION
# ==========================================

if __name__ == "__main__":
    # Execute Orbital TLE Debris classification pipeline
    X_tr, X_te, y_tr, y_te, le = load_and_preprocess_tle_data()
    if X_tr is not None:
        train_orbital_classifiers(X_tr, X_te, y_tr, y_te, le)
        
    # Execute Image Bounding Box pipeline
    train_image_debris_model()